//
//  EditorViewController.swift
//  MemeMe
//
//  Created by Raneem on 4/22/19.
//  Copyright © 2019 Raneem. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    
     var selectedMem: Meme!
    @IBOutlet weak var imagePickerView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagePickerView.image = selectedMem.memedImage
    }
}

