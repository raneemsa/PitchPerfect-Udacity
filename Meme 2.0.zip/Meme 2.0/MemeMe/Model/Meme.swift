//
//  Meme.swift
//  MemeMe
//
//  Created by Raneem on 4/22/19.
//  Copyright © 2019 Raneem. All rights reserved.
//

import Foundation
import UIKit

struct Meme {
    let topText: String
    let bottomText: String
    let originalImage: UIImage
    let memedImage: UIImage
    let imagePickerView = UIImage()
}
