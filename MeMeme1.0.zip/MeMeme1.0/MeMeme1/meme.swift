//
//  meme.swift
//  MeMeme1
//
//  Created by Raneem on 4/10/19.
//  Copyright © 2019 Raneem. All rights reserved.
//

import UIKit

struct meme{
    var topText:String
    var bottomText:String
    var orignalImage:UIImage?
    var meemdImage:UIImage?
    
    }
    


